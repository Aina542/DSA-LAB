#include<iostream>
using namespace std;
int main(){
	int Rows;
	int Columns;
	cout<<"Enter the number of Rows:"<<endl;
	cin>>Rows;
	cout<<"Enter the number of Columns:"<<endl;
	cin>>Columns;
	int arr[Rows][Columns];
	cout<<"Enter the element of array:"<<endl;
	for(int i=0;i<Rows;i++){
		for(int j=0; j<Columns; j++){
			cout<<"Enter the element of["<<i<<"]["<<j<<endl;
			cin>>arr[i][j];
		}
	}
	cout<<"The array is:"<<endl;
	for(int i=0; i<Rows; i++){
		for(int j=0; j<Columns; j++){
			cin>>arr[i][j];
		}
	}
	return 0;	
}