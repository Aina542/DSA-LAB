#include<iostream>
using namespace std;
int main(){
	int Rows;
	int Columns;
	cout<<"Enter the number of Rows:"<<endl;
	cin>>Rows;
	cout<<"Enter the number of Columns:"<<endl;
	cin>>Columns;
	int arr[Rows][Columns];
	cout<<"Enter the element of array:"<<endl;
	for(int i=0;i<Rows;i++){
		for(int j=0; j<Columns; j++){
			cout<<"Enter the element of["<<i<<"]["<<j<<endl;
			cin>>arr[i][j];
		}
	}
	int sum = 0;
	int maximum = arr[0][0];
	int minimum = arr[0][0];
	
	for (int i=0;i<Rows; i++){
		for (int j=0; j<Columns; j++){
		sum +=arr[i][j];
		
		if(arr[i][j]>maximum){
		maximum = arr[i][j];
        }
		if(arr[i][j]<minimum){
			minimum = arr[i][j];
		}
			cout<<"Sum of all elements:"<<sum<<endl;
			cout<<"Maximum number:"<<maximum<<endl;
			cout<<"Minimum number:"<<minimum<<endl;
			}
		}
		
		return 0;
	}