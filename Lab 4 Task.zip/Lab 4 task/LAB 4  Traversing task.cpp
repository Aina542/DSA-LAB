#include<iostream>
using namespace std;
int main(){

struct Node{
	int data;
	Node *next;
};
	 Node *n1 = new Node();
	Node *n2=new Node();
	Node *n3=new Node();
    	n1 -> data=10;
		n2 -> data=20;
		n3 -> data=30;
	
n1 -> next=n2;
n2 -> next=n3;
n3 -> next=NULL;
Node *head;
head = n1;
while(head!=NULL){
	cout<<head->data<<endl;
	head=head->next;
	
}
return 0;
}