#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    // Create nodes
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;

    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;

    Node* head = n1;

    cout << "Original List: ";
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ---------- Deletion at Specific Position ----------
    int pos = 3; // Example: delete node at position 3 (30)

    if (pos == 1 && head != NULL) { // delete 1st node
        Node* del = head;
        head = head->next;
        delete del;
    } else {
        Node* current = head;
        for (int i = 1; i < pos - 1 && current != NULL; i++) {
            current = current->next;
        }
        if (current != NULL && current->next != NULL) {
            Node* del = current->next;
            current->next = current->next->next;
            delete del;
        }
    }

    cout << "After Deletion at Position " << pos << ": ";
    temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    return 0;
}