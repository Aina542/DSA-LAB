#include<iostream>
using namespace std;
int main(){

struct Node{
	int data;
	Node *next;
};
	 Node *n1 = new Node();
	Node *n2=new Node();
	Node *n3=new Node();
	n1 -> data=10;
		n2 -> data=20;
		n3 -> data=30;
	
n1 -> next=n2;
n2 -> next=n3;
n3 -> next=NULL;
Node *head;
head = n1;
cout<<"Insertion in the middle"<<endl;
int insertion;
cout<<"which value do you want to insert against";
cin>>insertion;
Node *ptr;
ptr=head;
while(ptr ->data != insertion){
	cout<<ptr->data<<endl;
	ptr = ptr->next;
}
Node *nn = new Node;
nn -> data = 7;
nn -> next = n3;
n2->next=nn;
Node *j;
j = head;
cout<<"Final traversion"<<endl;
while(j!=NULL){
	cout<<j->data<<endl;
	j=j->next;
}

return 0;
}