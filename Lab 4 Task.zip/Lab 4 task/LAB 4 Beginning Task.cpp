#include<iostream>
using namespace std;
int main(){

struct Node{
	int data;
	Node *next;
};
	 Node *n1 = new Node();
	Node *n2=new Node();
	Node *n3=new Node();
	n1 -> data=10;
		n2 -> data=20;
		n3 -> data=30;
	
n1 -> next=n2;
n2 -> next=n3;
n3 -> next=NULL;
Node *head;
head = n1;
cout<<endl<<"Insertion at beginning"<<endl;
Node *nn1 = new Node();
nn1->data =5;
nn1-> next=head;
head=nn1;
Node *C1 = head;
while(C1!=NULL){
	cout<<C1->data<<endl;
	C1=C1->next;
}
	

return 0;
}