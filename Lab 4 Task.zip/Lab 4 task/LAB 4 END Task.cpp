#include<iostream>
using namespace std;
int main(){

struct Node{
	int data;
	Node *next;
};
	 Node *n1 = new Node();
	Node *n2=new Node();
	Node *n3=new Node();
	n1 -> data=10;
		n2 -> data=20;
		n3 -> data=30;
	
n1 -> next=n2;
n2 -> next=n3;
n3 -> next=NULL;
Node *head;
head = n1;
cout<<endl<<"Insertion at the end"<<endl;
Node *current = head;
while(current!=NULL){
	cout<<current->data<<endl;
	current=current->next;
}
Node *nn1 = new Node;
nn1 ->data = 3;
nn1->next;
return 0;
}