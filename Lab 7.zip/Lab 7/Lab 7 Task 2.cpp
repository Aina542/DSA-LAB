#include <iostream>
using namespace std;
class Inventory {
private:
    int serialNum;
    int manufactYear;
    int lotNum;
public:
    Inventory() {
        serialNum = manufactYear = lotNum = 0;
    }
    Inventory(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }
    void setData(int s, int y, int l) {
        serialNum = s;
        manufactYear = y;
        lotNum = l;
    }
    void display() {
        cout << "Serial Number: " << serialNum << endl;
        cout << "Manufacture Year: " << manufactYear << endl;
        cout << "Lot Number: " << lotNum << endl;
    }
};
class Node {
public:
    Inventory data;
    Node* next;
    Node(Inventory inv) {
        data = inv;
        next = NULL;
    }
};
class Stack {
private:
    Node* top;
public:
    Stack() {
        top = NULL;
    }
    void push(Inventory inv) {
        Node* newNode = new Node(inv);
        newNode->next = top;
        top = newNode;
        cout << "? Part added to inventory.\n";
    }
    void pop() {
        if (top == NULL){
            cout << "?? Inventory is empty. Nothing to remove.\n";
            return;
        }
        cout << "\nRemoving part from inventory:\n";
        top->data.display();
        Node* temp = top;
        top = top->next;
        delete temp;
    }
    void displayAll() {
        if (top == NULL) {
            cout << " Inventory is empty.\n";
            return;
        }
        cout << "\n Remaining Parts in Inventory:\n";
        Node* temp = top;
        while (temp != NULL) {
            cout << "-----------------------------\n";
            temp->data.display();
            temp = temp->next;
        }
        cout << "-----------------------------\n";
    }
};
int main() {
    Stack inventoryStack;
    int choice;
    cout << "========= INVENTORY MANAGEMENT SYSTEM =========\n";
    do {
        cout << "\nChoose an option:\n";
        cout << "1. Add a part to inventory\n";
        cout << "2. Remove a part from inventory\n";
        cout << "3. Exit and show remaining inventory\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int serial, year, lot;
            cout << "Enter Serial Number: ";
            cin >> serial;
            cout << "Enter Manufacture Year: ";
            cin >> year;
            cout << "Enter Lot Number: ";
            cin >> lot;

            Inventory inv(serial, year, lot);
            inventoryStack.push(inv);
        }
        else if (choice == 2) {
            inventoryStack.pop();
        }
        else if (choice == 3) {
            cout << "\nExiting program...\n";
        }
        else {
            cout << " Invalid choice. Try again.\n";
        }

    } while (choice != 3);
    inventoryStack.displayAll();
    return 0;
}