#include<iostream>
using namespace std;
int main(){
	int  *pointer = NULL;
	cout<<"The value of pointer is "<<endl;
	return 0;
}