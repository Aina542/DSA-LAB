#include<iostream>
using namespace std;
const int size = 3;
int main(){
	int var [size] = {5, 10, 15};
	int *ptr;
	//ptr will have array address, a[0]
	ptr = &var[size-1];
	for(int i= 0; i<size; i++){
	cout<< "Address of var[" << i << "] = ";
	cout<<ptr<<endl;
	cout<<"Value of var[" << i<< "] = ";
	cout<< *ptr <<endl;
	//point to the next location
	ptr--;
}
return 0;
}
