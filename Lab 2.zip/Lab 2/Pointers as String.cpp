#include<iostream>
using namespace std;
int main(){
	char str[] = "computer";
	char *cp=str;
	cout<<cp;
	return 0;
}