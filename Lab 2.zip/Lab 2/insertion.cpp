#include<iostream>
using namespace std;
int main()
{
	int arr[5]={1,2,3,4,5};
	int num, pos, size=5;
	cout<<"enter the number u want to add: ";
	cin>>num;
	cout<<"enter the position: ";
	cin>>pos;
	for( int i=5; i>pos; i--)
	{
		arr[i+1]=arr[i];
	}
	arr[pos]=num;
	size++;
	for(int i=0; i<size; i++)
	{
		cout<<arr[i]<<" ";
	}
	return 0;
}