#include<iostream>
using namespace  std;
int main(){
	int a= 58;
	int *ptr= &a;
	int **ptr= &ptr;
	cout<<a;
	cout<<*ptr;
	cout<<**ptr;
	return 0;
}