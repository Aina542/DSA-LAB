#include<iostream>
using namespace std;
int main(){
    int size=5;
    int value;
    int index;
    cout<<"Original Array:"<<endl;
    int Student[5] = {14,63,45,85,70};
    for(int i=0;i<size;i++){
    	cout<<Student[i]<<" ";
	}
    cout<<"\nEnter the position (0-5) where you want to enter the new value:"<<endl;
    cin>>index;
    cout<<"Enter the value"<<endl;
    cin>>value;
    for(int i=size;i>index;i--){
    	Student[i]=Student[i-1];
	}
	Student[index]=value;
	size++;
	cout<<"Array after insertion:"<<endl;
	for(int i=0;i<size;i++){
		cout<<Student[i]<<" ";
	}
    return 0;
}
