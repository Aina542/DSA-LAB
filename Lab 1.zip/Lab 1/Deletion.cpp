#include<iostream>
using namespace std;

int main(){
    int Array[5]={10, 20, 30, 40, 50};
    int size=5;
    int index;
    cout<<"Original array: ";
    for(int i=0;i<size;i++){
        cout<<Array[i]<<" ";
    }
    cout<<endl;
    cout<<"Enter the index(0-4) of number you want to delete: ";
    cin>>index;
    if(index>=0&& index<size){
    	for(int i=index;i<size;i++){
    		Array[i]=Array[i+1];
		}
		size--;
		cout<<"Array after deletion:"<<endl;
		for(int i=0;i<size;i++){
			cout<<Array[i]<<" ";
		}
		cout<<endl;
	}
	else{
		cout<<"Invalid index!"<<endl;
	}
    return 0;
}
