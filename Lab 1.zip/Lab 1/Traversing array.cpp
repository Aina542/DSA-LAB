#include<iostream>
using namespace std;
int main(){
	cout<<"Enter marks of 10 students:"<<endl;
    int Students[10];
    for(int i=0;i<10;i++){
  	    cin>>Students[i];
    }
    for(int j=0;j<10;j++){
    	cout << "Student " <<j<< " scored " <<Students[j] << " marks" <<endl;
    }
    return 0;
	}
