#include<iostream>
using namespace std;
int main(){
	int index;
	int newValue;
	int Array[5]={12,34,54,56,65};
	cout<<"Original Array:"<<endl;
	for(int i=0;i<5;i++){
		cout<<Array[i]<<" ";
	}
	cout<<endl;
	cout<<"Enter the index (0 to 4) of the number you want to update: ";
    cin>>index;
    cout<<"Enter the new value: ";
    cin>>newValue;

    Array[index] = newValue;
    cout<<"Updated array: ";
    for(int i = 0; i < 5; i++){
        cout<<Array[i]<<" ";
    }
    cout<<endl;
    return 0;
}
