#include <iostream>
#include <string>
using namespace std;

struct Applicant {
    int applicant_id;
    float height, weight, eyesight;
    string testStatus;
    Applicant* next;
    Applicant* prev;
};

// Queue implemented using Doubly Linked List
class ApplicantQueue {
private:
    Applicant* front;
    Applicant* rear;

public:
    ApplicantQueue() {
        front = rear = nullptr;
    }

    // Add applicant at the end (enqueue)
    void enqueue(int id, float height, float weight, float eyesight, string status) {
        Applicant* newNode = new Applicant{id, height, weight, eyesight, status, nullptr, nullptr};

        if (!rear) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
        cout << "Applicant " << id << " joined the line.\n";
    }

    void dequeue() {
        if (!front) {
            cout << "No applicants in the queue.\n";
            return;
        }
        Applicant* temp = front;
        cout << "Applicant " << temp->applicant_id << " completed the test and left the line.\n";
        front = front->next;
        if (front) front->prev = nullptr;
        else rear = nullptr;
        delete temp;
    }

    void removeAtPosition(int position) {
        if (!front) {
            cout << "Queue is empty.\n";
            return;
        }

        Applicant* current = front;
        int index = 1;

        // Traverse to the given position
        while (current && index < position) {
            current = current->next;
            index++;
        }

        if (!current) {
            cout << "Invalid position.\n";
            return;
        }

        cout << "Applicant " << current->applicant_id << " (at position " 
             << position << ") left the line due to urgency.\n";

        // Adjust links
        if (current->prev)
            current->prev->next = current->next;
        else
            front = current->next;  // removing first element

        if (current->next)
            current->next->prev = current->prev;
        else
            rear = current->prev;   // removing last element

        delete current;
    }

    void display() {
        if (!front) {
            cout << "Queue is empty.\n";
            return;
        }

        cout << "\nCurrent Queue:\n";
        Applicant* temp = front;
        int pos = 1;
        while (temp) {
            cout << pos++ << ". ID: " << temp->applicant_id
                 << " | Height: " << temp->height
                 << " | Weight: " << temp->weight
                 << " | Eyesight: " << temp->eyesight
                 << " | Status: " << temp->testStatus << endl;
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    ApplicantQueue q;

    q.enqueue(110, 5.5, 65.5, 6.5, "Waiting");
    q.enqueue(120, 6.1, 70.0, 6.2, "Waiting");
    q.enqueue(130, 4.5, 68.3, 6.8, "Waiting");
    q.enqueue(140, 6.3, 75.0, 6.9, "Waiting");
    q.enqueue(150, 5.2, 66.7, 6.4, "Waiting");
    q.enqueue(160, 6.7, 69.1, 6.3, "Waiting");
    q.enqueue(170, 7.1, 73.5, 6.7, "Waiting");

    q.display();

    // 2nd applicant leaves (urgency)
    q.removeAtPosition(2);

    q.display();

    // First applicant gives test and leaves
    q.dequeue();

    q.display();

    return 0;
}