#include <iostream>
#include <queue>
#include <stack>
#include <string>
using namespace std;

class TruckSystem {
private:
    queue<int> road;     
    stack<int> garage;   
    
public:
    void On_road(int truck_id) {
        road.push(truck_id);
        cout << "Truck " << truck_id << " arrived on the road.\n";
    }

    void Enter_garage(int truck_id) {
        if (road.empty()) {
            cout << "No trucks on road to enter the garage.\n";
            return;
        }

        if (road.front() == truck_id) {
            road.pop();
            garage.push(truck_id);
            cout << "Truck " << truck_id << " entered the garage.\n";
        } else {
            cout << "Truck " << truck_id << " is not at the front of the road.\n";
        }
    }

    void Exit_garage(int truck_id) {
        if (garage.empty()) {
            cout << "Garage is empty!\n";
            return;
        }

        if (garage.top() == truck_id) {
            garage.pop();
            cout << "Truck " << truck_id << " exited the garage.\n";
        } else {
            cout << "Truck " << truck_id << " is not near garage door!\n";
        }
    }

    void Show_trucks(string location) {
        if (location == "road") {
            if (road.empty()) {
                cout << "No trucks on the road.\n";
                return;
            }

            cout << "\nTrucks currently on the road:\n";
            queue<int> temp = road;  // copy to display
            while (!temp.empty()) {
                cout << temp.front() << " ";
                temp.pop();
            }
            cout << endl;
        }

        else if (location == "garage") {
            if (garage.empty()) {
                cout << "Garage is empty.\n";
                return;
            }

            cout << "\nTrucks currently in the garage (top to bottom):\n";
            stack<int> temp = garage; 
            while (!temp.empty()) {
                cout << temp.top() << " ";
                temp.pop();
            }
            cout << endl;
        }

        else {
            cout << "Invalid location! Use 'road' or 'garage'.\n";
        }
    }
};


int main() {
    TruckSystem system;

    // Example simulation
    system.On_road(101);
    system.On_road(102);
    system.On_road(103);

    system.Show_trucks("road");

    system.Enter_garage(101);
    system.Enter_garage(102);

    system.Show_trucks("garage");
    system.Show_trucks("road");

    system.Exit_garage(103);  // Not allowed (error)
    system.Exit_garage(102);  // Valid exit

    system.Show_trucks("garage");

    return 0;
}