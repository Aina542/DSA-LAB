#include <iostream>
#include <string>
using namespace std;

struct Player {
    string name;
    int score;
    Player* prev;
    Player* next;
};

Player* head = NULL;

// Function to create a new player node
Player* createPlayer(string name, int score) {
    Player* newPlayer = new Player();
    newPlayer->name = name;
    newPlayer->score = score;
    newPlayer->prev = newPlayer->next = NULL;
    return newPlayer;
}

// Function to add player in sorted order (ascending by score)
void addPlayer(string name, int score) {
    Player* newPlayer = createPlayer(name, score);

    if (head == NULL) {
        head = newPlayer;
        head->next = head;
        head->prev = head;
        return;
    }

    Player* temp = head;

    // If new player has lowest score ? insert before head
    if (score < head->score) {
        Player* last = head->prev;
        newPlayer->next = head;
        newPlayer->prev = last;
        last->next = newPlayer;
        head->prev = newPlayer;
        head = newPlayer;
        return;
    }

    // Traverse until correct position is found
    do {
        if (temp->next == head || temp->next->score > score) {
            break;
        }
        temp = temp->next;
    } while (temp != head);

    newPlayer->next = temp->next;
    newPlayer->prev = temp;
    temp->next->prev = newPlayer;
    temp->next = newPlayer;
}

// Function to delete a player by name
void deletePlayer(string name) {
    if (head == NULL) {
        cout << "No players in the list.\n";
        return;
    }

    Player* temp = head;
    do {
        if (temp->name == name) {
            if (temp->next == head && temp->prev == head) {
                // Only one node
                delete temp;
                head = NULL;
                cout << "Player " << name << " deleted.\n";
                return;
            }

            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;

            if (temp == head)
                head = temp->next;

            delete temp;
            cout << "Player " << name << " deleted.\n";
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Player not found.\n";
}

// Display all players in ascending order
void displayAll() {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }

    cout << "Players List (Ascending):\n";
    Player* temp = head;
    do {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->next;
    } while (temp != head);
}

// Display all players in descending order
void displayDescending() {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }

    cout << "Players in Descending Order:\n";
    Player* temp = head->prev;
    do {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->prev;
    } while (temp != head->prev);
}

// Display the player with the lowest score
void displayLowestScore() {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }
    cout << "Lowest Score: " << head->name << " - " << head->score << "\n";
}

// Display all players having same score
void displaySameScore(int score) {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }

    bool found = false;
    cout << "Players with score " << score << ":\n";
    Player* temp = head;
    do {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << "\n";
            found = true;
        }
        temp = temp->next;
    } while (temp != head);

    if (!found)
        cout << "No players found with score " << score << ".\n";
}

// Display backward starting from a specific player
void displayBackwardFrom(string name) {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }

    Player* temp = head;
    bool found = false;
    do {
        if (temp->name == name) {
            found = true;
            break;
        }
        temp = temp->next;
    } while (temp != head);

    if (!found) {
        cout << "Player not found.\n";
        return;
    }

    cout << "Backward from " << name << ":\n";
    Player* start = temp;
    do {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->prev;
    } while (temp != start);
}

int main() {
    int choice;
    string name;
    int score;

    do {
        cout << "\n--- Golf Tournament Menu (Circular Doubly Linked List) ---\n";
        cout << "1. Add Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display All Players\n";
        cout << "4. Display Descending Order\n";
        cout << "5. Display Lowest Score\n";
        cout << "6. Display Players with Same Score\n";
        cout << "7. Display Backward from Player\n";
        cout << "8. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Player Name: ";
                cin >> name;
                cout << "Enter Score: ";
                cin >> score;
                addPlayer(name, score);
                break;

            case 2:
                cout << "Enter Player Name to delete: ";
                cin >> name;
                deletePlayer(name);
                break;

            case 3:
                displayAll();
                break;

            case 4:
                displayDescending();
                break;

            case 5:
                displayLowestScore();
                break;

            case 6:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(score);
                break;

            case 7:
                cout << "Enter Player Name: ";
                cin >> name;
                displayBackwardFrom(name);
                break;

            case 8:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid choice.\n";
        }

    } while (choice != 8);

    return 0;
}