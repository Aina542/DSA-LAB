#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL; 

Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

void createList(int n) {
    if (n <= 0) return;

    Node* temp;
    for (int i = 0; i < n; i++) {
        int value;
        cout << "Enter value for node " << i + 1 << ": ";
        cin >> value;
        Node* newNode = createNode(value);

        if (head == NULL) {
            head = newNode;
            head->next = head;
            head->prev = head;
            temp = head;
        } else {
            newNode->prev = temp;
            newNode->next = head;
            temp->next = newNode;
            head->prev = newNode;
            temp = newNode;
        }
    }
}

// b) Insert node at beginning
void addAtBeginning(int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
        head->next = head;
        head->prev = head;
    } else {
        Node* last = head->prev;
        newNode->next = head;
        newNode->prev = last;
        last->next = newNode;
        head->prev = newNode;
        head = newNode;
    }
}

// c) Insert node after value 45
void addAfterValue(int value, int newValue) {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == value) {
            Node* newNode = createNode(newValue);
            newNode->next = temp->next;
            newNode->prev = temp;
            temp->next->prev = newNode;
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Value " << value << " not found in list.\n";
}

// d) Delete node at beginning
void deleteAtBeginning() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    if (head->next == head) { 
        delete head;
        head = NULL;
        return;
    }

    Node* last = head->prev;
    Node* temp = head;
    head = head->next;
    head->prev = last;
    last->next = head;
    delete temp;
}

// e) Delete node after value 45
void deleteAfterValue(int value) {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    Node* temp = head;
    do {
        if (temp->data == value) {
            Node* delNode = temp->next;
            if (delNode == head) {  
                cout << "No node exists after value " << value << ".\n";
                return;
            }
            temp->next = delNode->next;
            delNode->next->prev = temp;
            delete delNode;
            return;
        }
        temp = temp->next;
    } while (temp != head);

    cout << "Node after value " << value << " not found.\n";
}

void displayList() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }

    Node* temp = head;
    cout << "Circular Doubly Linked List: ";
    do {
        cout << temp->data << " <-> ";
        temp = temp->next;
    } while (temp != head);
    cout << "(back to head)\n";
}

int main() {
    int n;
    cout << "Enter number of nodes: ";
    cin >> n;
    createList(n);
    displayList();

    cout << "\nInsert at beginning (value 100):\n";
    addAtBeginning(100);
    displayList();

    cout << "\nInsert after 45 (value 200):\n";
    addAfterValue(45, 200);
    displayList();

    cout << "\nDelete at beginning:\n";
    deleteAtBeginning();
    displayList();

    cout << "\nDelete after 45:\n";
    deleteAfterValue(45);
    displayList();

    return 0;
}

